// Famous artworks dataset (manual because Wikipedia summary doesn't always include them)
const artworks = {
    "Vincent van Gogh": "https://upload.wikimedia.org/wikipedia/commons/e/ee/Van_Gogh_-_Starry_Night_-_Google_Art_Project.jpg",
    "Michelangelo": "https://upload.wikimedia.org/wikipedia/commons/e/eb/%27David%27_by_Michelangelo_Fir_JBU004_denoised.jpg",
    "Ansel Adams": "https://upload.wikimedia.org/wikipedia/commons/2/2a/Adams-moonrise.jpg",
    "Beeple": "https://uploads7.wikiart.org/temp/beeple-everydays.jpg"
  };
  
  // Open Preview Modal
  async function openPreview(wikiPage) {
    try {
      let response = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${wikiPage}`);
      let data = await response.json();
  
      // Fill modal with Wikipedia data
      document.getElementById("previewTitle").innerText = data.title;
      document.getElementById("wikiExtract").innerText = data.extract;
      document.getElementById("artistPhoto").src = data.thumbnail ? data.thumbnail.source : '';
      document.getElementById("wikiLink").href = data.content_urls.desktop.page;
  
      // Load famous artwork if available
      let artImg = artworks[data.title] || "";
      document.getElementById("artPhoto").src = artImg;
  
      document.getElementById("previewModal").style.display = "block";
    } catch (error) {
      console.error("Error fetching Wikipedia data:", error);
    }
  }
  
  // Close Modal
  function closeModal() {
    document.getElementById("previewModal").style.display = "none";
  }
  