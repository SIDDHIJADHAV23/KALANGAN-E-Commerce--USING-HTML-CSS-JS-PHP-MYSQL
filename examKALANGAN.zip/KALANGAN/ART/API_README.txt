API endpoints (placed in ART/api/)
- add_to_cart.php  (POST JSON {product_id, quantity}) - requires login (PHP session)
- get_cart.php     (GET) - returns cart items
- update_cart.php  (POST JSON {cart_id, quantity})
- remove_from_cart.php (POST JSON {cart_id})
- add_to_wishlist.php (POST JSON {product_id})
- get_wishlist.php (GET)
- checkout.php     (POST JSON {cart: [{product_id, price, quantity}, ...], method: 'card'})
- orders.php       (GET) - user order history
- order_list.php   (GET) - admin (user_id==1) order list

Make sure to import db_extended.sql into your MySQL (database name kalangan_db) and use config.php to connect.
