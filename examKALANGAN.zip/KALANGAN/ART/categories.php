
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Kalangan — Categories</title>
<link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Montserrat:wght@300;500;700&display=swap" rel="stylesheet">
<style>
/* Basic CSS */
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Montserrat',sans-serif;background:#fffaf9;color:#222;line-height:1.4}

/* Navbar */
header{position:sticky;top:0;background:rgba(255,255,255,0.9);backdrop-filter:blur(4px);box-shadow:0 2px 10px rgba(0,0,0,0.05);padding:1rem;z-index:900}
.navwrap{max-width:1200px;margin:0 auto;display:flex;justify-content:space-between;align-items:center}
.brand-small{display:flex;align-items:center;gap:.6rem}
.logo-mark{width:48px;height:48px;border-radius:12px;background:linear-gradient(135deg,#eec5ee,#9c6c9c);display:flex;align-items:center;justify-content:center;box-shadow:0 4px 10px rgba(0,0,0,0.1)}
.logo-mark span{font-family:'Pacifico';color:#5a2c5a;font-size:1.4rem}
.brand-title{font-family:'Pacifico';color:#5a2c5a;font-size:1.25rem}
nav ul{display:flex;gap:1rem;list-style:none}
nav a{text-decoration:none;color:#5a2c5a;font-weight:600;padding:.4rem .6rem;border-radius:8px}
nav a:hover{background:#eec5ee;color:#3f1a3f}

/* Grid cards */
.frame-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:1rem;max-width:1200px;margin:2rem auto}
.frame-card{background:#fffaf9;border-radius:12px;overflow:hidden;box-shadow:0 10px 30px rgba(0,0,0,0.05);display:flex;flex-direction:column;align-items:center;padding:1rem;transition:transform .3s}
.frame-card:hover{transform:translateY(-5px)}
.frame-wrap{padding:10px;background:#a08c7e;border:8px solid #7c6a5e;border-radius:12px} /* WOODEN FRAME STYLE */
.frame-wrap img{width:100%;height:200px;object-fit:cover;border-radius:4px}
.art-title{font-weight:700;margin-top:.5rem;color:#3f1a3f}
.art-sub{font-size:.85rem;color:#7a477a;margin-bottom:.5rem}
.btn{padding:.5rem .8rem;border:none;border-radius:8px;background:#5a2c5a;color:#fff;cursor:pointer;transition:transform .2s}
.btn:hover{transform:scale(1.05)}
.modal{position:fixed;inset:0;background:rgba(0,0,0,0.5);display:flex;justify-content:center;align-items:center;padding:1rem;opacity:0;visibility:hidden;transition:.3s}
.modal.show{opacity:1;visibility:visible}
.modal-card{background:#fff;border-radius:12px;max-width:800px;width:100%;display:flex;flex-wrap:wrap;padding:1rem;gap:1rem;position:relative}
.modal-left{flex:1;min-width:250px}
.modal-left img{width:100%;height:300px;object-fit:cover;border-radius:8px;border:10px solid #7c6a5e;background:#a08c7e} /* WOODEN FRAME IN MODAL */
.modal-right{flex:1;min-width:200px;display:flex;flex-direction:column;gap:.5rem}
.modal-close{position:absolute;top:10px;right:10px;font-size:1.5rem;border:none;background:none;cursor:pointer}
.artist-thumb{width:60px;height:60px;border-radius:8px;object-fit:cover;border:3px solid #a08c7e}
#wikiLink{margin-top:.5rem;text-decoration:none;text-align:center;display:inline-block}
#wikiRating{margin-top:.5rem;color:#5a2c5a;font-weight:700;font-size:.9rem}

/* About */
#about{max-width:1200px;margin:2rem auto;padding:1rem}
#about h2{font-family:'Pacifico';color:#5a2c5a;margin-bottom:1rem}

/* Contact form attractive */
#contact{max-width:800px;margin:2rem auto;padding:2rem;background:#fffaf9;border-radius:12px;box-shadow:0 8px 30px rgba(0,0,0,0.08)}
#contact h2{font-family:'Pacifico';color:#5a2c5a;margin-bottom:1rem;text-align:center}
#contact form{display:flex;flex-direction:column;gap:1rem}
#contact input,#contact textarea{padding:.8rem;border-radius:8px;border:1px solid #ddd;width:100%;transition:.2s}
#contact input:focus,#contact textarea:focus{border-color:#5a2c5a;outline:none;box-shadow:0 0 5px rgba(90,44,90,0.3)}
#contact button{background:#5a2c5a;color:white;padding:.8rem;border-radius:8px;border:none;cursor:pointer;transition:.3s}
#contact button:hover{background:#3f1a3f;transform:scale(1.02)}

/* Footer */
footer{background:#eec5ee;padding:1rem;text-align:center;margin-top:2rem;border-top:1px solid #7a477a}
footer a{text-decoration:none;color:#3f1a3f;margin:0 5px}
</style>
</head>
<body>

<header>
<div class="navwrap">
<div class="brand-small">
<div class="logo-mark"><span>K</span></div>
<div class="brand-title">Kalangan</div>
</div>
<nav>
<ul>
<li><a href="main.html">Home</a></li>
<li><a href="gallery.html">Gallery</a></li>
<li><a href="#" aria-current="page">Categories</a></li>
<li><a href="#about">About</a></li>
<li><a href="#contact">Contact</a></li>
</ul>
</nav>
</div>
</header>

<section class="frame-grid">
<script>
const categories=[
{title:'Painting',artist:'Vincent van Gogh',img:1,wiki:'Vincent_van_Gogh'},
{title:'Sculpture',artist:'Michelangelo',img:2,wiki:'Michelangelo'},
{title:'Photography',artist:'Ansel Adams',img:3,wiki:'Ansel_Adams'},
{title:'Digital Art',artist:'Beeple',img:4,wiki:'Beeple_(artist)'},
{title:'Street Art',artist:'Banksy',img:5,wiki:'Banksy'},
{title:'Illustration',artist:'Hayao Miyazaki',img:6,wiki:'Hayao_Miyazaki'},
{title:'Printmaking',artist:'Albrecht Dürer',img:7,wiki:'Albrecht_Dürer'},
{title:'Textile',artist:'Anni Albers',img:8,wiki:'Anni_Albers'},
{title:'Ceramics',artist:'Bernard Leach',img:9,wiki:'Bernard_Leach'},
{title:'Mixed Media',artist:'Yayoi Kusama',img:10,wiki:'Yayoi_Kusama'},
{title:'Calligraphy',artist:'Wang Xizhi',img:11,wiki:'Wang_Xizhi'},
{title:'Architecture',artist:'Frank Lloyd Wright',img:12,wiki:'Frank_Lloyd_Wright'},
{title:'Modern Art',artist:'Pablo Picasso',img:13,wiki:'Pablo_Picasso'},
{title:'Abstract',artist:'Wassily Kandinsky',img:14,wiki:'Wassily_Kandinsky'},
{title:'Surrealism',artist:'Salvador Dalí',img:15,wiki:'Salvador_Dalí'}
];
categories.forEach(c=>{
document.write(`<div class="frame-card">
<div class="frame-wrap"><img src="https://picsum.photos/600/400?random=${c.img}" alt="${c.title}"></div>
<div class="art-title">${c.title}</div>
<div class="art-sub">${c.artist}</div>
<button class="btn explore-btn" data-wiki="${c.wiki}" data-img="${c.img}">Explore More</button>
</div>`);
});
</script>
</section>

<!-- Modal -->
<div id="modal" class="modal">
<div class="modal-card">
<button class="modal-close">&times;</button>
<div class="modal-left"><img id="modalArt" src=""></div>
<div class="modal-right">
<div style="display:flex;gap:.5rem;align-items:center">
<img id="artistThumb" class="artist-thumb" style="display:none">
<div>
<h3 id="modalTitle"></h3>
<div id="modalSub" style="font-size:.9rem;color:#7a477a;font-weight:600"></div>
</div>
</div>
<p id="modalDesc"></p>
<div id="wikiRating"></div>
<a id="wikiLink" class="btn" target="_blank">Read on Wikipedia</a>
</div>
</div>
</div>

<!-- About -->
<section id="about">
<h2>About Us</h2>
<p>Kalangan is an online art showcase dedicated to celebrating creativity across painting, sculpture, photography, digital art and beyond. We bring curated collections and artist previews to help you discover and connect with art.</p>
</section>

<!-- Contact -->
<section id="contact">
<h2>Contact Us</h2>
<form id="contactForm">
<input type="text" placeholder="Your Name" required>
<input type="email" placeholder="Your Email" required>
<textarea placeholder="Message" rows="4"></textarea>
<button type="submit" class="btn">Send Message</button>
</form>
</section>

<footer>
© 2025 Kalangan • Made with love 🎨 <br>
<a href="#">Instagram</a> <a href="#">Pinterest</a> <a href="#contact">Contact</a>
</footer>

<script>
// Modal
const modal=document.getElementById('modal');
const modalArt=document.getElementById('modalArt');
const modalTitle=document.getElementById('modalTitle');
const modalSub=document.getElementById('modalSub');
const modalDesc=document.getElementById('modalDesc');
const wikiLink=document.getElementById('wikiLink');
const artistThumb=document.getElementById('artistThumb');
const wikiRating=document.getElementById('wikiRating');

document.querySelectorAll('.explore-btn').forEach(btn=>{
btn.addEventListener('click',async()=>{
const wiki=btn.dataset.wiki;
const imgNum=btn.dataset.img;
modalArt.src=`https://picsum.photos/900/600?random=${imgNum}`;
modalTitle.textContent='Loading...';
modalSub.textContent='';
modalDesc.textContent='Fetching info...';
wikiRating.textContent='';
artistThumb.style.display='none';
wikiLink.href='#';
modal.classList.add('show');

try{
const res=await fetch('https://en.wikipedia.org/api/rest_v1/page/summary/'+encodeURIComponent(wiki));
if(!res.ok) throw new Error('Not found');
const data=await res.json();
modalTitle.textContent=data.title||wiki.replace(/_/g,' ');
modalSub.textContent=data.type ? data.type.charAt(0).toUpperCase()+data.type.slice(1):'';
modalDesc.textContent=data.extract||'No summary available.';
wikiLink.href=data.content_urls?.desktop?.page || ('https://en.wikipedia.org/wiki/'+wiki);
if(data.thumbnail?.source){artistThumb.src=data.thumbnail.source; artistThumb.style.display='inline-block'}
wikiRating.textContent=data.description ? 'Rating: '+data.description : '';
}catch(err){modalTitle.textContent=wiki.replace(/_/g,' '); modalDesc.textContent='Could not fetch info.'; wikiLink.href='https://en.wikipedia.org/wiki/'+wiki;}
});
});

document.querySelector('.modal-close').addEventListener('click',()=>{modal.classList.remove('show')});
modal.addEventListener('click',e=>{if(e.target===modal) modal.classList.remove('show')});
document.addEventListener('keydown',e=>{if(e.key==='Escape') modal.classList.remove('show')});

// Contact form demo
document.getElementById('contactForm').addEventListener('submit',e=>{e.preventDefault();alert('Message sent (demo)');e.target.reset();});
</script>
</body>
</html>
