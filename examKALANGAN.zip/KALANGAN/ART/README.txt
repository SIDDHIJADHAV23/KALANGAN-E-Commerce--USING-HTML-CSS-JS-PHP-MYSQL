Kalangan Art Website - Updated Version
====================================

✨ Features & Enhancements
-------------------------
1. Design & Styling
   - Pastel Theme: green, pink, purple, blue pastel palette applied site-wide.
   - Polaroid Wooden Frames: Gallery images are wrapped in Polaroid-style wooden frames with hover zoom.
   - Vintage Look Pages: Cart, Wishlist, Orders, Checkout pages use paper-texture backgrounds, brush borders,
     dashed wooden-style frames and cursive headings for a vintage/artistic feel.

2. Navbar & Footer
   - Navbar from Home (main.html) copied to all pages (gallery, cart, wishlist, orders, checkout, etc.).
   - Footer is consistent on every page and set to stick to the bottom of the viewport/layout.

3. Pages Updated
   - main.html       -> Home page (base layout and navbar/footer source)
   - gallery.html    -> Gallery with Polaroid wooden frames
   - cart.html       -> Vintage-styled Cart page
   - wishlist.html   -> Vintage-styled Wishlist page
   - orders.html     -> Vintage-styled Orders page
   - checkout.html   -> Payment page styled like the other vintage pages

4. CSS Enhancements (style.css)
   - .polaroid-frame   -> Wooden Polaroid frames for images
   - .vintage-card     -> Vintage background card with dashed border + paper texture
   - .vintage-heading  -> Cursive heading style with subtle shadow
   - .brush-border     -> Brush-stroke style border for decorative sections
   - Footer layout adjusted to keep footer at bottom (flexbox on body/html)

5. Functionality & Backend
   - PHP files and database assets intact: config.php, db.sql, login.php, signup.php, categories.php, etc.
   - JavaScript files (script.js, cscript.js) preserved for interactions and API calls.

🚀 How to Run
-------------
1. Unzip the project (kalangan_final.zip).
2. Place the folder into your local web server directory (e.g., XAMPP's htdocs).
3. Import `db.sql` into your MySQL server (use phpMyAdmin or MySQL CLI).
4. Update database credentials in `config.php`.
5. Open the site in a browser via: http://localhost/<project-folder>/main.html

Notes:
- If you want a screenshot preview included, tell me and I can add one separately.
- If something looks off when you run it (CSS not applied, missing images, paths), paste the error or a screenshot and I will help debug.

Enjoy your updated Kalangan art website! 🎨
