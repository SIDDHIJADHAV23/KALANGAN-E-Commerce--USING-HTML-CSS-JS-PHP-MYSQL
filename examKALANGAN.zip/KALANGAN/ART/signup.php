<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Sign Up - Kalangan</title>
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --purple-dark: #3f1a3f;
      --purple-base: #5a2c5a;
      --purple-medium: #7a477a;
      --pink-light: #eec5ee;
    }
    body {
      margin: 0;
      font-family: 'Montserrat', sans-serif;
      background: url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1400&q=80') no-repeat center/cover;
      display: flex; justify-content: center; align-items: center;
      min-height: 100vh;
    }
    .form-box {
      background: rgba(255,255,255,0.15);
      backdrop-filter: blur(15px);
      padding: 2.5rem;
      border-radius: 18px;
      width: 650px;
      box-shadow: 0 8px 30px rgba(0,0,0,0.25);
      animation: fadeUp 0.8s ease;
    }
    .form-box h2 {
      font-family: 'Pacifico', cursive;
      text-align: center;
      color: var(--purple-dark);
      font-size: 2.2rem;
      margin-bottom: 1rem;
    }
    form {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
    }
    form input {
      padding: 0.9rem;
      border-radius: 30px;
      border: none;
      background: rgba(255,255,255,0.3);
      color: var(--purple-dark);
      outline: none;
      transition: 0.3s;
      font-weight: 500;
    }
    form input:focus {
      background: rgba(255,255,255,0.6);
      transform: scale(1.03);
    }
    button {
      grid-column: span 2;
      padding: 1rem;
      border-radius: 30px;
      border: none;
      background: var(--purple-base);
      color: white;
      font-weight: 700;
      font-size: 1rem;
      cursor: pointer;
      transition: .3s;
    }
    button:hover {
      background: var(--purple-dark);
      transform: translateY(-2px);
    }
    .links {
      text-align: center;
      margin-top: 1rem;
    }
    .links a { color: var(--purple-medium); font-weight: bold; text-decoration: none; }
    .links a:hover { text-decoration: underline; }
    @keyframes fadeUp { from {opacity:0; transform:translateY(20px);} to {opacity:1; transform:translateY(0);} }
  </style>
  <script>
    function validateForm() {
      let email = document.forms["signupForm"]["email"].value;
      let phone = document.forms["signupForm"]["phone"].value;
      let pass  = document.forms["signupForm"]["password"].value;
      let cpass = document.forms["signupForm"]["confirm_password"].value;
      const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
      const phonePattern = /^[0-9]{10}$/;
      if (!email.match(emailPattern)) { alert("Enter a valid email."); return false; }
      if (!phone.match(phonePattern)) { alert("Phone must be 10 digits."); return false; }
      if (pass.length < 6) { alert("Password must be at least 6 characters."); return false; }
      if (pass !== cpass) { alert("Passwords do not match."); return false; }
      return true;
    }
  </script>
</head>
<body>
  <div class="form-box">
    <h2>Sign Up</h2>
    <form name="signupForm" method="POST" onsubmit="return validateForm()">
      <input type="text" name="name" placeholder="Full Name" required>
      <input type="email" name="email" placeholder="Email" required>
      <input type="text" name="phone" placeholder="Phone (10 digits)" required>
      <input type="text" name="country" placeholder="Country" required>
      <input type="password" name="password" placeholder="Password" required>
      <input type="password" name="confirm_password" placeholder="Confirm Password" required>
      <button type="submit" name="signup">Register</button>
    </form>
    <div class="links">Already have an account? <a href="login.php">Login</a></div>
  </div>
</body>
</html>

<?php
if (isset($_POST['signup'])) {
    $name    = $_POST['name'];
    $email   = $_POST['email'];
    $phone   = $_POST['phone'];
    $country = $_POST['country'];
    $pass    = $_POST['password'];
    $cpass   = $_POST['confirm_password'];

    if ($pass !== $cpass) {
        echo "<script>alert('Passwords do not match');</script>";
    } else {
        $password = password_hash($pass, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $name, $email, $password);
        if ($stmt->execute()) {
            echo "<script>alert('Signup successful! Please login.'); window.location='login.php';</script>";
        } else {
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
        }
    }
}
?>
