<?php
session_start();
include 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login - Kalangan</title>
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --purple-dark: #3f1a3f;
      --purple-base: #5a2c5a;
      --purple-medium: #7a477a;
    }
    body {
      margin: 0;
      font-family: 'Montserrat', sans-serif;
      background: url('https://images.unsplash.com/photo-1503264116251-35a269479413?auto=format&fit=crop&w=1400&q=80') no-repeat center/cover;
      display: flex; justify-content: center; align-items: center;
      min-height: 100vh;
    }
    .form-box {
      background: rgba(255,255,255,0.15);
      backdrop-filter: blur(15px);
      padding: 2.5rem;
      border-radius: 18px;
      width: 400px;
      box-shadow: 0 8px 30px rgba(0,0,0,0.25);
      animation: fadeUp 0.8s ease;
    }
    .form-box h2 {
      font-family: 'Pacifico', cursive;
      text-align: center;
      color: var(--purple-dark);
      margin-bottom: 1.5rem;
    }
    input {
      width: 100%;
      padding: 0.9rem;
      margin-bottom: 1rem;
      border-radius: 30px;
      border: none;
      background: rgba(255,255,255,0.3);
      color: var(--purple-dark);
      outline: none;
      transition: 0.3s;
    }
    input:focus { background: rgba(255,255,255,0.6); transform: scale(1.03); }
    button {
      width: 100%;
      padding: 1rem;
      border-radius: 30px;
      border: none;
      background: var(--purple-base);
      color: white;
      font-weight: 700;
      cursor: pointer;
      transition: .3s;
    }
    button:hover { background: var(--purple-dark); transform: translateY(-2px); }
    .links { text-align: center; margin-top: 1rem; }
    .links a { color: var(--purple-medium); font-weight: bold; text-decoration: none; }
  </style>
  <script>
    function validateLogin() {
      let email = document.forms["loginForm"]["email"].value;
      let pass  = document.forms["loginForm"]["password"].value;
      const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
      if (!email.match(emailPattern)) { alert("Enter a valid email."); return false; }
      if (pass.length < 6) { alert("Password must be at least 6 characters."); return false; }
      return true;
    }
  </script>
</head>
<body>
  <div class="form-box">
    <h2>Login</h2>
    <form name="loginForm" method="POST" onsubmit="return validateLogin()">
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit" name="login">Login</button>
    </form>
    <div class="links">Don’t have an account? <a href="signup.php">Sign up</a></div>
  </div>
</body>
</html>

<?php
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM users WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        header("Location: main.html");
        exit();
    } else {
        echo "<script>alert('Invalid email or password.');</script>";
    }
}
?>
