<?php
session_start();
require_once __DIR__ . "/../db.php";
if (!isset($_SESSION['admin_id'])) { header('Location: index.php'); exit; }
$uid = isset($_GET['user_id'])? (int)$_GET['user_id'] : 0;
$user = $conn->query('SELECT id, name, email, created_at FROM users WHERE id='.$uid)->fetch_assoc();
$logins = $conn->query('SELECT * FROM user_logins WHERE user_id='.$uid.' ORDER BY at DESC LIMIT 50');
$orders = $conn->query('SELECT * FROM orders WHERE user_id='.$uid.' ORDER BY created_at DESC LIMIT 50');
?>
<!doctype html><html><head><meta charset="utf-8"><title>User History</title><link rel="stylesheet" href="admin.css"></head>
<body>
<div class="topbar"><div class="container"><strong>Kalangan Admin</strong></div><div style="padding-right:20px"><a href="users.php" class="btn">Back</a></div></div>
<div class="container">
  <h3>User History for <?php echo htmlspecialchars($user['email'] ?? 'Unknown'); ?></h3>
  <div class="card"><h4>Recent Logins</h4>
    <table class="table"><thead><tr><th>At</th><th>IP</th></tr></thead><tbody>
    <?php while($r = $logins->fetch_assoc()): ?>
      <tr><td><?php echo $r['at']; ?></td><td><?php echo htmlspecialchars($r['ip']); ?></td></tr>
    <?php endwhile; ?>
    </tbody></table>
  </div>

  <div class="card"><h4>Orders</h4>
    <table class="table"><thead><tr><th>ID</th><th>Total</th><th>Status</th><th>Placed</th></tr></thead><tbody>
    <?php while($o = $orders->fetch_assoc()): ?>
      <tr><td><?php echo $o['id']; ?></td><td><?php echo number_format($o['total'],2); ?></td><td><?php echo $o['status']; ?></td><td><?php echo $o['created_at']; ?></td></tr>
    <?php endwhile; ?>
    </tbody></table>
  </div>
</div>
</body></html>
