<?php
session_start();
require_once __DIR__ . "/../db.php";
if (!isset($_SESSION['admin_id'])) { header('Location: index.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'toggle_status' && isset($_POST['user_id'])) {
        $id = (int)$_POST['user_id'];
        $cur = $conn->query('SELECT status FROM users WHERE id='.$id)->fetch_assoc()['status'];
        $next = ($cur === 'active') ? 'inactive' : 'active';
        $u = $conn->prepare('UPDATE users SET status=? WHERE id=?');
        $u->bind_param('si', $next, $id);
        $u->execute();
    }
}

$users = $conn->query('SELECT id, name, email, status, created_at FROM users ORDER BY created_at DESC');
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Users - Admin</title><link rel="stylesheet" href="admin.css"></head>
<body>
<div class="topbar"><div class="container"><strong>Kalangan Admin</strong></div><div style="padding-right:20px"><a href="dashboard.php" class="btn">Back</a></div></div>
<div class="container">
  <h3>Users</h3>
  <table class="table">
    <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
    <tbody>
    <?php while($u = $users->fetch_assoc()): ?>
      <tr>
        <td><?php echo $u['id']; ?></td>
        <td><?php echo htmlspecialchars($u['name']); ?></td>
        <td><?php echo htmlspecialchars($u['email']); ?></td>
        <td><?php echo $u['status']; ?></td>
        <td><?php echo $u['created_at']; ?></td>
        <td>
          <form method="post" style="display:inline">
            <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
            <input type="hidden" name="action" value="toggle_status">
            <button class="btn" type="submit"><?php echo ($u['status'] === 'active') ? 'Deactivate' : 'Activate'; ?></button>
          </form>
          <a class="btn" href="user_history.php?user_id=<?php echo $u['id']; ?>">History</a>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>
</div>
</body></html>
