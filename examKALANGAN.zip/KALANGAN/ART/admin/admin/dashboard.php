<?php
session_start();
require_once __DIR__ . "/../db.php";
if (!isset($_SESSION['admin_id'])) { header('Location: index.php'); exit; }

// fetch overview counts
$users = $conn->query('SELECT COUNT(*) as c FROM users')->fetch_assoc()['c'] ?? 0;
$orders = $conn->query('SELECT COUNT(*) as c FROM orders')->fetch_assoc()['c'] ?? 0;
$revenue = $conn->query('SELECT IFNULL(SUM(amount),0) as s FROM payments WHERE status = "completed"')->fetch_assoc()['s'] ?? 0;
$pending = $conn->query('SELECT COUNT(*) as c FROM payments WHERE status = "pending"')->fetch_assoc()['c'] ?? 0;
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Dashboard - Admin</title><link rel="stylesheet" href="admin.css"></head>
<body>
<div class="topbar">
  <div class="container"> <strong>Kalangan Admin</strong></div>
  <div style="padding-right:20px"><a href="logout.php" class="btn">Logout</a></div>
</div>
<div class="container">
  <h3>Dashboard</h3>
  <div class="card-grid">
    <div class="card"><h4>Total Users</h4><p style="font-size:22px"><?php echo $users; ?></p></div>
    <div class="card"><h4>Total Orders</h4><p style="font-size:22px"><?php echo $orders; ?></p></div>
    <div class="card"><h4>Revenue</h4><p style="font-size:22px">INR <?php echo number_format($revenue,2); ?></p></div>
    <div class="card"><h4>Pending Payments</h4><p style="font-size:22px"><?php echo $pending; ?></p></div>
  </div>

  <div style="display:flex; gap:12px; margin-bottom:16px">
    <a class="btn" href="users.php">Users</a>
    <a class="btn" href="products.php">Products</a>
    <a class="btn" href="orders.php">Orders</a>
    <a class="btn" href="payments.php">Payments</a>
    <a class="btn" href="analytics.php">Analytics</a>
  </div>

  <div class="card">
    <h4>Recent Orders</h4>
    <table class="table">
      <thead><tr><th>ID</th><th>User</th><th>Total</th><th>Status</th><th>Placed</th></tr></thead>
      <tbody>
      <?php
      $res = $conn->query('SELECT o.id, o.total, o.status, o.created_at, u.email FROM orders o LEFT JOIN users u ON u.id = o.user_id ORDER BY o.created_at DESC LIMIT 8');
      while($r = $res->fetch_assoc()){
          echo '<tr><td>'.$r['id'].'</td><td>'.htmlspecialchars($r['email']).'</td><td>'.number_format($r['total'],2).'</td><td>'.$r['status'].'</td><td>'.$r['created_at'].'</td></tr>';
      }
      ?>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>
