<?php
// Simple receipt generator (HTML). You can extend to PDF with libraries.
session_start();
require_once __DIR__ . "/../db.php";
if (!isset($_SESSION['admin_id'])) { header('Location: index.php'); exit; }
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$order = $conn->query('SELECT o.*, u.email FROM orders o LEFT JOIN users u ON u.id=o.user_id WHERE o.id='.$id)->fetch_assoc();
$items = $conn->query('SELECT * FROM order_items WHERE order_id='.$id);
?>
<!doctype html><html><head><meta charset="utf-8"><title>Receipt #<?php echo $id; ?></title><link rel="stylesheet" href="admin.css"></head><body>
<div class="container" style="max-width:700px">
  <h2>Receipt - Order #<?php echo $id; ?></h2>
  <div><strong>User:</strong> <?php echo htmlspecialchars($order['email'] ?? ''); ?></div>
  <div><strong>Total:</strong> INR <?php echo number_format($order['total'],2); ?></div>
  <div style="margin-top:12px"><h4>Items</h4>
    <table class="table"><thead><tr><th>Product</th><th>Price</th><th>Qty</th></tr></thead><tbody>
    <?php while($it = $items->fetch_assoc()): ?>
      <tr><td><?php echo htmlspecialchars($it['product_name']); ?></td><td><?php echo number_format($it['price'],2); ?></td><td><?php echo $it['quantity']; ?></td></tr>
    <?php endwhile; ?>
    </tbody></table>
  </div>
  <div style="margin-top:12px"><button onclick="window.print()" class="btn">Print</button></div>
</div>
</body></html>
