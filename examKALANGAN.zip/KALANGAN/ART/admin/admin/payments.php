<?php
session_start();
require_once __DIR__ . "/../db.php";
if (!isset($_SESSION['admin_id'])) { header('Location: index.php'); exit; }

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['action'])) {
    if ($_POST['action']==='mark_refund' && isset($_POST['pid'])) {
        $pid = (int)$_POST['pid'];
        $u = $conn->prepare('UPDATE payments SET status = ? WHERE id = ?');
        $st = 'refunded';
        $u->bind_param('si', $st, $pid);
        $u->execute();
    }
}

$payments = $conn->query('SELECT p.*, o.user_id FROM payments p LEFT JOIN orders o ON o.id = p.order_id ORDER BY p.created_at DESC');
?>
<!doctype html><html><head><meta charset="utf-8"><title>Payments - Admin</title><link rel="stylesheet" href="admin.css"></head><body>
<div class="topbar"><div class="container"><strong>Kalangan Admin</strong></div><div style="padding-right:20px"><a href="dashboard.php" class="btn">Back</a></div></div>
<div class="container">
  <h3>Payments</h3>
  <table class="table"><thead><tr><th>ID</th><th>Order</th><th>Amount</th><th>Status</th><th>Ref</th><th>Action</th></tr></thead><tbody>
  <?php while($p = $payments->fetch_assoc()): ?>
    <tr>
      <td><?php echo $p['id']; ?></td>
      <td><?php echo $p['order_id']; ?></td>
      <td><?php echo number_format($p['amount'],2); ?></td>
      <td><?php echo $p['status']; ?></td>
      <td><?php echo htmlspecialchars($p['payment_ref']); ?></td>
      <td>
        <?php if($p['status'] !== 'refunded'): ?>
        <form method="post" style="display:inline"><input type="hidden" name="pid" value="<?php echo $p['id']; ?>"><button class="btn" name="action" value="mark_refund" type="submit">Mark Refunded</button></form>
        <?php else: ?> <span class="small">Already refunded</span> <?php endif; ?>
      </td>
    </tr>
  <?php endwhile; ?>
  </tbody></table>
</div>
</body></html>
