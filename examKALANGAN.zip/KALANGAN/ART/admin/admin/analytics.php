<?php
session_start();
require_once __DIR__ . "/../db.php";
if (!isset($_SESSION['admin_id'])) { header('Location: index.php'); exit; }

// Simple sales by date (last 30 days)
$res = $conn->query("SELECT DATE(created_at) as dt, IFNULL(SUM(amount),0) as total FROM payments WHERE status='completed' AND created_at > DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY DATE(created_at) ORDER BY dt ASC");
$data = [];
while($r = $res->fetch_assoc()) { $data[] = $r; }
?>
<!doctype html><html><head><meta charset="utf-8"><title>Analytics</title><link rel="stylesheet" href="admin.css"></head><body>
<div class="topbar"><div class="container"><strong>Kalangan Admin</strong></div><div style="padding-right:20px"><a href="dashboard.php" class="btn">Back</a></div></div>
<div class="container">
  <h3>Analytics</h3>
  <div class="card"><h4>Sales (last 30 days)</h4>
    <table class="table"><thead><tr><th>Date</th><th>Total</th></tr></thead><tbody>
    <?php foreach($data as $d): ?>
      <tr><td><?php echo $d['dt']; ?></td><td><?php echo number_format($d['total'],2); ?></td></tr>
    <?php endforeach; ?>
    </tbody></table>
  </div>
</div>
</body></html>
