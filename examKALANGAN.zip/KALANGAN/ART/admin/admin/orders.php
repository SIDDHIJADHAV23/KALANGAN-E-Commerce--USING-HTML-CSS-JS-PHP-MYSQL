<?php
session_start();
require_once __DIR__ . "/../db.php";
if (!isset($_SESSION['admin_id'])) { header('Location: index.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action']==='update_status') {
    $oid = (int)$_POST['order_id'];
    $status = $_POST['status'];
    $u = $conn->prepare('UPDATE orders SET status=? WHERE id=?');
    $u->bind_param('si', $status, $oid);
    $u->execute();
}

$orders = $conn->query('SELECT o.*, u.email FROM orders o LEFT JOIN users u ON u.id=o.user_id ORDER BY o.created_at DESC');
?>
<!doctype html><html><head><meta charset="utf-8"><title>Orders - Admin</title><link rel="stylesheet" href="admin.css"></head><body>
<div class="topbar"><div class="container"><strong>Kalangan Admin</strong></div><div style="padding-right:20px"><a href="dashboard.php" class="btn">Back</a></div></div>
<div class="container">
  <h3>Orders</h3>
  <table class="table"><thead><tr><th>ID</th><th>User</th><th>Total</th><th>Status</th><th>Placed</th><th>Action</th></tr></thead><tbody>
  <?php while($o = $orders->fetch_assoc()): ?>
    <tr>
      <td><?php echo $o['id']; ?></td>
      <td><?php echo htmlspecialchars($o['email']); ?></td>
      <td><?php echo number_format($o['total'],2); ?></td>
      <td><?php echo $o['status']; ?></td>
      <td><?php echo $o['created_at']; ?></td>
      <td>
         <form method="post" style="display:inline">
           <input type="hidden" name="order_id" value="<?php echo $o['id']; ?>">
           <select name="status">
             <option <?php if($o['status']==='processing') echo 'selected'; ?>>processing</option>
             <option <?php if($o['status']==='shipped') echo 'selected'; ?>>shipped</option>
             <option <?php if($o['status']==='delivered') echo 'selected'; ?>>delivered</option>
             <option <?php if($o['status']==='cancelled') echo 'selected'; ?>>cancelled</option>
           </select>
           <button class="btn" type="submit" name="action" value="update_status">Update</button>
         </form>
         <a class="btn" href="order_view.php?id=<?php echo $o['id']; ?>">View</a>
      </td>
    </tr>
  <?php endwhile; ?>
  </tbody></table>
</div></body></html>
