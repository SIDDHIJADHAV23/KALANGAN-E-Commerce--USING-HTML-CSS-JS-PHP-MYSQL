<?php
session_start();
require_once __DIR__ . "/../db.php";
if (!isset($_SESSION['admin_id'])) { header('Location: index.php'); exit; }

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'delete' && isset($_POST['pid'])) {
        $pid = (int)$_POST['pid'];
        $stmt = $conn->prepare('DELETE FROM products WHERE id=?');
        $stmt->bind_param('i',$pid); $stmt->execute();
        $message = 'Deleted product.';
    } else {
        // add/edit
        $name = $_POST['name'] ?? '';
        $slug = $_POST['slug'] ?? '';
        $desc = $_POST['description'] ?? '';
        $price = floatval($_POST['price'] ?? 0);
        $inventory = intval($_POST['inventory'] ?? 0);
        $category = $_POST['category'] ?? '';
        $image = '';
        if (!empty($_FILES['image']['name'])) {
            $target = __DIR__ . '/../uploads/' . basename($_FILES['image']['name']);
            move_uploaded_file($_FILES['image']['tmp_name'], $target);
            $image = 'uploads/' . basename($_FILES['image']['name']);
        }
        $stmt = $conn->prepare('INSERT INTO products (name, slug, description, price, inventory, category, image) VALUES (?,?,?,?,?,?,?)');
        $stmt->bind_param('ssdiiss', $name, $slug, $desc, $price, $inventory, $category, $image);
        $stmt->execute();
        $message = 'Product saved.';
    }
}

$products = $conn->query('SELECT * FROM products ORDER BY created_at DESC');
?>
<!doctype html><html><head><meta charset="utf-8"><title>Products - Admin</title><link rel="stylesheet" href="admin.css"></head><body>
<div class="topbar"><div class="container"><strong>Kalangan Admin</strong></div><div style="padding-right:20px"><a href="dashboard.php" class="btn">Back</a></div></div>
<div class="container">
  <h3>Products</h3>
  <?php if($message): ?><div style="margin-bottom:12px;color:green"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
  <div class="card">
    <h4>Add Product</h4>
    <form method="post" enctype="multipart/form-data">
      <input type="hidden" name="action" value="save">
      <div class="form-row"><label>Name</label><input class="input" name="name" required></div>
      <div class="form-row"><label>Slug (url)</label><input class="input" name="slug" required></div>
      <div class="form-row"><label>Description</label><textarea class="input" name="description"></textarea></div>
      <div style="display:flex; gap:8px">
        <div style="flex:1"><label>Price</label><input class="input" name="price" required></div>
        <div style="width:140px"><label>Inventory</label><input class="input" name="inventory" required></div>
      </div>
      <div class="form-row"><label>Category</label><input class="input" name="category"></div>
      <div class="form-row"><label>Image</label><input type="file" name="image"></div>
      <div style="text-align:right"><button class="btn" type="submit">Save</button></div>
    </form>
  </div>

  <div class="card"><h4>Existing Products</h4>
    <table class="table"><thead><tr><th>ID</th><th>Name</th><th>Price</th><th>Inventory</th><th>Actions</th></tr></thead><tbody>
    <?php while($p = $products->fetch_assoc()): ?>
      <tr>
        <td><?php echo $p['id']; ?></td>
        <td><?php echo htmlspecialchars($p['name']); ?></td>
        <td><?php echo number_format($p['price'],2); ?></td>
        <td><?php echo $p['inventory']; ?></td>
        <td>
          <form method="post" style="display:inline">
            <input type="hidden" name="pid" value="<?php echo $p['id']; ?>">
            <input type="hidden" name="action" value="delete">
            <button class="btn" type="submit">Delete</button>
          </form>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody></table>
  </div>
</div></body></html>
