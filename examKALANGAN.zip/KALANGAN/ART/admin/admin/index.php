<?php
// admin/index.php - login page
session_start();
require_once __DIR__ . "/../db.php";

if (isset($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare('SELECT id, email, password FROM admins WHERE email = ? LIMIT 1');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        $dbpass = $row['password'];
        $ok = false;
        // First try password_verify (hashed). If DB has plain password, allow login and rehash.
        if (password_verify($password, $dbpass)) {
            $ok = true;
        } elseif ($password === $dbpass) { // fallback for plain text legacy
            $ok = true;
            // rehash and update
            $newHash = password_hash($password, PASSWORD_DEFAULT);
            $u = $conn->prepare('UPDATE admins SET password = ? WHERE id = ?');
            $u->bind_param('si', $newHash, $row['id']);
            $u->execute();
        }
        if ($ok) {
            $_SESSION['admin_id'] = $row['id'];
            $_SESSION['admin_email'] = $row['email'];
            header('Location: dashboard.php');
            exit;
        } else {
            $message = 'Invalid credentials';
        }
    } else {
        $message = 'Invalid credentials';
    }
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin Login - Kalangan</title>
<link rel="stylesheet" href="admin.css">
</head>
<body>
<div class="login-box">
  <h2 style="margin-top:0">Admin Login</h2>
  <?php if ($message): ?><div style="color:red; margin-bottom:10px;"><?php echo htmlspecialchars($message); ?></div><?php endif; ?>
  <form method="post">
    <div class="form-row"><label>Email</label><input class="input" type="email" name="email" required></div>
    <div class="form-row"><label>Password</label><input class="input" type="password" name="password" required></div>
    <div style="text-align:right"><button class="btn" type="submit">Login</button></div>
  </form>
  <p class="small" style="margin-top:12px">Use the credential provided in conversation. Password will be stored hashed after first login.</p>
</div>
</body>
</html>
