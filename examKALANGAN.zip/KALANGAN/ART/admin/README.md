# Kalangan - Admin Panel

This package contains a simple admin panel (PHP + MySQL) to manage users, products, orders, payments and basic analytics.

## Quick setup
1. Place the `kalangan_admin` folder into your web server root (e.g., `htdocs` for XAMPP).
2. Create a MySQL database named `kalangan` (or change in `db.php`).
3. Import `database.sql` into your DB to create the tables.
4. If you want to create the admin user quickly, insert the row into the `admins` table with email `kalangan@gmail.com` and password `kalangan123` (the code supports automatic hashing on first login if stored plaintext).
5. Open `http://localhost/kalangan_admin/admin` and login.

**Security notes**
- Change database credentials in `db.php`.
- Remove example/plain admin password after first login or allow the app to rehash it (it will).
- Use HTTPS for production and enable 2FA integration if needed.

