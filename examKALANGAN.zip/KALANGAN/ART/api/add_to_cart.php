<?php
session_start();
header('Content-Type: application/json');
include __DIR__ . '/../config.php';
if(!isset($_SESSION['user_id'])) { echo json_encode(['error'=>'Not logged in']); exit; }
$uid = $_SESSION['user_id'];
$data = json_decode(file_get_contents('php://input'), true);
$product_id = intval($data['product_id'] ?? 0);
$qty = intval($data['quantity'] ?? 1);
if(!$product_id){ echo json_encode(['error'=>'Invalid product']); exit; }
// check exist
$sql = "SELECT id, quantity FROM carts WHERE user_id=? AND product_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii",$uid,$product_id);
$stmt->execute();
$res = $stmt->get_result();
if($row = $res->fetch_assoc()){
    $newq = $row['quantity'] + $qty;
    $u = $conn->prepare("UPDATE carts SET quantity=? WHERE id=?");
    $u->bind_param("ii",$newq,$row['id']);
    $u->execute();
} else {
    $i = $conn->prepare("INSERT INTO carts (user_id, product_id, quantity) VALUES (?,?,?)");
    $i->bind_param("iii",$uid,$product_id,$qty);
    $i->execute();
}
echo json_encode(['success'=>true]);
