<?php
session_start();
header('Content-Type: application/json');
include __DIR__ . '/../config.php';
if(!isset($_SESSION['user_id'])) { echo json_encode(['error'=>'Not logged in']); exit; }
$uid = $_SESSION['user_id'];
$data = json_decode(file_get_contents('php://input'), true);
$cart_id = intval($data['cart_id'] ?? 0);
if(!$cart_id){ echo json_encode(['error'=>'Invalid cart id']); exit; }
$d = $conn->prepare("DELETE FROM carts WHERE id=? AND user_id=?");
$d->bind_param("ii",$cart_id,$uid);
$d->execute();
echo json_encode(['success'=>true]);
