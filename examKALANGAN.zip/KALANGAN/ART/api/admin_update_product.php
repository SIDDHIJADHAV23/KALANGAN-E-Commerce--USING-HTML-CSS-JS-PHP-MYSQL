<?php
session_start();
include __DIR__ . '/../config.php';
if(!isset($_SESSION['user_id']) || $_SESSION['user_id']!=1){ echo json_encode(['error'=>'Not authorized']); exit; }
$data = json_decode(file_get_contents('php://input'), true);
$id = intval($data['id'] ?? 0);
$title = $data['title'] ?? '';
$img = $data['img'] ?? '';
$price = floatval($data['price'] ?? 0);
$desc = $data['description'] ?? '';
$stmt = $conn->prepare('UPDATE products SET title=?, img=?, price=?, description=? WHERE id=?');
$stmt->bind_param('sddsi',$title,$img,$price,$desc,$id);
$stmt->execute();
echo json_encode(['success'=>true]);
