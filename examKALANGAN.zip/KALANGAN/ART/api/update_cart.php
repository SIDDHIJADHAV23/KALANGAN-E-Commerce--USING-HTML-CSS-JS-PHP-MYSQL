<?php
session_start();
header('Content-Type: application/json');
include __DIR__ . '/../config.php';
if(!isset($_SESSION['user_id'])) { echo json_encode(['error'=>'Not logged in']); exit; }
$uid = $_SESSION['user_id'];
$data = json_decode(file_get_contents('php://input'), true);
$cart_id = intval($data['cart_id'] ?? 0);
$qty = intval($data['quantity'] ?? 1);
if(!$cart_id){ echo json_encode(['error'=>'Invalid cart id']); exit; }
$u = $conn->prepare("UPDATE carts SET quantity=? WHERE id=? AND user_id=?");
$u->bind_param("iii",$qty,$cart_id,$uid);
$u->execute();
if($u->affected_rows>=0) echo json_encode(['success'=>true]);
else echo json_encode(['error'=>'Update failed']);
