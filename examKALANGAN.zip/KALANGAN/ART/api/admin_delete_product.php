<?php
session_start();
include __DIR__ . '/../config.php';
if(!isset($_SESSION['user_id']) || $_SESSION['user_id']!=1){ echo json_encode(['error'=>'Not authorized']); exit; }
$id = intval($_GET['id'] ?? 0);
$stmt = $conn->prepare('DELETE FROM products WHERE id=?');
$stmt->bind_param('i',$id);
$stmt->execute();
echo json_encode(['success'=>true]);
