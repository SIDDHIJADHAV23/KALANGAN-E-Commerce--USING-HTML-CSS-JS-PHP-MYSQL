<?php
session_start();
include __DIR__ . '/../config.php';
// naive admin check
if(!isset($_SESSION['user_id']) || $_SESSION['user_id']!=1){ echo json_encode(['error'=>'Not authorized']); exit; }
$data = json_decode(file_get_contents('php://input'), true);
$title = $data['title'] ?? '';
$img = $data['img'] ?? '';
$price = floatval($data['price'] ?? 0);
$desc = $data['description'] ?? '';
$stmt = $conn->prepare('INSERT INTO products (title,img,price,description) VALUES (?,?,?,?)');
$stmt->bind_param('sdds',$title,$img,$price,$desc);
$stmt->execute();
echo json_encode(['success'=>true,'id'=>$stmt->insert_id]);
