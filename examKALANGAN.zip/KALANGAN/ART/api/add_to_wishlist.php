<?php
session_start();
header('Content-Type: application/json');
include __DIR__ . '/../config.php';
if(!isset($_SESSION['user_id'])) { echo json_encode(['error'=>'Not logged in']); exit; }
$uid = $_SESSION['user_id'];
$data = json_decode(file_get_contents('php://input'), true);
$product_id = intval($data['product_id'] ?? 0);
if(!$product_id){ echo json_encode(['error'=>'Invalid product']); exit; }
$check = $conn->prepare("SELECT id FROM wishlists WHERE user_id=? AND product_id=?");
$check->bind_param("ii",$uid,$product_id);
$check->execute();
$r = $check->get_result();
if($r->fetch_assoc()){
    echo json_encode(['message'=>'Already in wishlist']);
    exit;
}
$i = $conn->prepare("INSERT INTO wishlists (user_id,product_id) VALUES (?,?)");
$i->bind_param("ii",$uid,$product_id);
$i->execute();
echo json_encode(['success'=>true]);
