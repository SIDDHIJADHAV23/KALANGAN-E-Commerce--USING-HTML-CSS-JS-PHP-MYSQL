<?php
session_start();
header('Content-Type: application/json');
include __DIR__ . '/../config.php';
if(!isset($_SESSION['user_id'])) { echo json_encode(['error'=>'Not logged in']); exit; }
$uid = $_SESSION['user_id'];
$sql = "SELECT w.id as wish_id, p.id as product_id, p.title, p.img, p.price FROM wishlists w JOIN products p ON w.product_id=p.id WHERE w.user_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$uid);
$stmt->execute();
$res = $stmt->get_result();
echo json_encode(['wishlist'=>$res->fetch_all(MYSQLI_ASSOC)]);
