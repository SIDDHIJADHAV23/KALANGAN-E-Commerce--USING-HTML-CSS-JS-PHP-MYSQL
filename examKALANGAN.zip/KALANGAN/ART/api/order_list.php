<?php
// admin endpoint - list all orders
session_start();
header('Content-Type: application/json');
include __DIR__ . '/../config.php';
// naive admin check: user id 1 is admin
if(!isset($_SESSION['user_id']) || $_SESSION['user_id']!=1){ echo json_encode(['error'=>'Not authorized']); exit; }
$sql = "SELECT o.*, u.name, u.email FROM orders o JOIN users u ON o.user_id=u.id ORDER BY o.created_at DESC";
$res = $conn->query($sql);
echo json_encode(['orders'=>$res->fetch_all(MYSQLI_ASSOC)]);
