<?php
session_start();
header('Content-Type: application/json');
include __DIR__ . '/../config.php';
if(!isset($_SESSION['user_id'])) { echo json_encode(['error'=>'Not logged in']); exit; }
$uid = $_SESSION['user_id'];
$data = json_decode(file_get_contents('php://input'), true);
$cart = $data['cart'] ?? [];
if(!is_array($cart) || count($cart)==0){ echo json_encode(['error'=>'Cart empty']); exit; }
// compute total and create order
$total = 0.0;
foreach($cart as $it){
    $total += floatval($it['price'])*intval($it['quantity']);
}
$ins = $conn->prepare("INSERT INTO orders (user_id,total,status) VALUES (?,?,?)");
$status = 'pending';
$ins->bind_param("ids",$uid,$total,$status);
$ins->execute();
$order_id = $ins->insert_id;
$itst = $conn->prepare("INSERT INTO order_items (order_id,product_id,quantity,price) VALUES (?,?,?,?)");
foreach($cart as $it){
    $pid = intval($it['product_id']);
    $qty = intval($it['quantity']);
    $price = floatval($it['price']);
    $itst->bind_param("iiid",$order_id,$pid,$qty,$price);
    $itst->execute();
}
// optional: empty user's cart
$d = $conn->prepare("DELETE FROM carts WHERE user_id=?");
$d->bind_param("i",$uid);
$d->execute();
// record a simulated payment
$p = $conn->prepare("INSERT INTO payments (order_id,method,amount,status) VALUES (?,?,?,?)");
$method = $data['method'] ?? 'card';
$paystatus = 'success';
$p->bind_param("isds",$order_id,$method,$total,$paystatus);
$p->execute();
echo json_encode(['success'=>true,'order_id'=>$order_id]);
