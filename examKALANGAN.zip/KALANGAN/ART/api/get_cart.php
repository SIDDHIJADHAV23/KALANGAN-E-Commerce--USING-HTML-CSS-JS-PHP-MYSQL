<?php
session_start();
header('Content-Type: application/json');
include __DIR__ . '/../config.php';
if(!isset($_SESSION['user_id'])) {
    echo json_encode(['error'=>'Not logged in']);
    exit;
}
$uid = $_SESSION['user_id'];
$sql = "SELECT c.id as cart_id, p.id as product_id, p.title, p.img, p.price, c.quantity FROM carts c JOIN products p ON c.product_id=p.id WHERE c.user_id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$uid);
$stmt->execute();
$res = $stmt->get_result();
$rows = $res->fetch_all(MYSQLI_ASSOC);
echo json_encode(['cart'=>$rows]);
