<?php
session_start();
header('Content-Type: application/json');
include __DIR__ . '/../config.php';
if(!isset($_SESSION['user_id'])) { echo json_encode(['error'=>'Not logged in']); exit; }
$uid = $_SESSION['user_id'];
$sql = "SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i",$uid);
$stmt->execute();
$res = $stmt->get_result();
$orders = $res->fetch_all(MYSQLI_ASSOC);
echo json_encode(['orders'=>$orders]);
