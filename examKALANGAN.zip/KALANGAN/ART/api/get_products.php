<?php
header('Content-Type: application/json');
include __DIR__ . '/../config.php';
$res = $conn->query('SELECT * FROM products ORDER BY created_at DESC');
echo json_encode(['products'=>$res->fetch_all(MYSQLI_ASSOC)]);
