CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15) NOT NULL,
    country VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  img VARCHAR(1000) DEFAULT NULL,
  price DECIMAL(10,2) NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cart
CREATE TABLE IF NOT EXISTS carts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Wishlist
CREATE TABLE IF NOT EXISTS wishlists (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  product_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Orders and items
CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  status VARCHAR(50) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Payments (simulated)
CREATE TABLE IF NOT EXISTS payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  method VARCHAR(100),
  amount DECIMAL(10,2) NOT NULL,
  status VARCHAR(50) DEFAULT 'success',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- Insert sample products (30 items) based on gallery data
INSERT INTO products (title, img, price, description) VALUES
('Artwork 1','https://picsum.photos/600/400/?random=5',1200,'Sample description for Artwork 1.'),
('Artwork 2','https://picsum.photos/600/400/?random=6',1400,'Sample description for Artwork 2.'),
('Artwork 3','https://picsum.photos/600/400/?random=7',1600,'Sample description for Artwork 3.'),
('Artwork 4','https://picsum.photos/600/400/?random=8',1800,'Sample description for Artwork 4.'),
('Artwork 5','https://picsum.photos/600/400/?random=9',2000,'Sample description for Artwork 5.'),
('Artwork 6','https://picsum.photos/600/400/?random=10',2200,'Sample description for Artwork 6.'),
('Artwork 7','https://picsum.photos/600/400/?random=11',2400,'Sample description for Artwork 7.'),
('Artwork 8','https://picsum.photos/600/400/?random=12',2600,'Sample description for Artwork 8.'),
('Artwork 9','https://picsum.photos/600/400/?random=13',2800,'Sample description for Artwork 9.'),
('Artwork 10','https://picsum.photos/600/400/?random=14',3000,'Sample description for Artwork 10.'),
('Artwork 11','https://picsum.photos/600/400/?random=15',3200,'Sample description for Artwork 11.'),
('Artwork 12','https://picsum.photos/600/400/?random=16',3400,'Sample description for Artwork 12.'),
('Artwork 13','https://picsum.photos/600/400/?random=17',3600,'Sample description for Artwork 13.'),
('Artwork 14','https://picsum.photos/600/400/?random=18',3800,'Sample description for Artwork 14.'),
('Artwork 15','https://picsum.photos/600/400/?random=19',4000,'Sample description for Artwork 15.'),
('Artwork 16','https://picsum.photos/600/400/?random=20',4200,'Sample description for Artwork 16.'),
('Artwork 17','https://picsum.photos/600/400/?random=21',4400,'Sample description for Artwork 17.'),
('Artwork 18','https://picsum.photos/600/400/?random=22',4600,'Sample description for Artwork 18.'),
('Artwork 19','https://picsum.photos/600/400/?random=23',4800,'Sample description for Artwork 19.'),
('Artwork 20','https://picsum.photos/600/400/?random=24',5000,'Sample description for Artwork 20.'),
('Artwork 21','https://picsum.photos/600/400/?random=25',5200,'Sample description for Artwork 21.'),
('Artwork 22','https://picsum.photos/600/400/?random=26',5400,'Sample description for Artwork 22.'),
('Artwork 23','https://picsum.photos/600/400/?random=27',5600,'Sample description for Artwork 23.'),
('Artwork 24','https://picsum.photos/600/400/?random=28',5800,'Sample description for Artwork 24.'),
('Artwork 25','https://picsum.photos/600/400/?random=29',6000,'Sample description for Artwork 25.'),
('Artwork 26','https://picsum.photos/600/400/?random=30',6200,'Sample description for Artwork 26.'),
('Artwork 27','https://picsum.photos/600/400/?random=31',6400,'Sample description for Artwork 27.'),
('Artwork 28','https://picsum.photos/600/400/?random=32',6600,'Sample description for Artwork 28.'),
('Artwork 29','https://picsum.photos/600/400/?random=33',6800,'Sample description for Artwork 29.'),
('Artwork 30','https://picsum.photos/600/400/?random=34',7000,'Sample description for Artwork 30.');
