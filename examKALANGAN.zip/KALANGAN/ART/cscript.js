document.addEventListener('DOMContentLoaded',()=>{

    const cards=document.querySelectorAll('.frame-card');
    cards.forEach(c=>c.classList.add('show'));
    
    const previewModal=document.getElementById('previewModal');
    const modalArt=document.getElementById('modalArt');
    const modalTitle=document.getElementById('modalTitle');
    const modalSubtitle=document.getElementById('modalSubtitle');
    const modalDesc=document.getElementById('modalDesc');
    const wikiLink=document.getElementById('wikiLink');
    const artistThumb=document.getElementById('artistThumb');
    
    document.querySelectorAll('.explore-btn').forEach(btn=>{
      btn.addEventListener('click',async ()=>{
        const wikiSlug=btn.dataset.wiki;
        modalArt.src=btn.previousElementSibling.querySelector('img').src;
        modalTitle.textContent='Loading…';
        modalSubtitle.textContent='';
        modalDesc.textContent='Fetching Wikipedia...';
        artistThumb.style.display='none';
        wikiLink.href='#';
        previewModal.classList.add('show');
        previewModal.setAttribute('aria-hidden','false');
    
        try{
          const resp=await fetch('https://en.wikipedia.org/api/rest_v1/page/summary/'+encodeURIComponent(wikiSlug));
          const data=await resp.json();
          modalTitle.textContent=data.title||wikiSlug.replace(/_/g,' ');
          modalSubtitle.textContent=data.type?data.type.charAt(0).toUpperCase()+data.type.slice(1):'';
          modalDesc.textContent=data.extract||'No summary available.';
          wikiLink.href=(data.content_urls && data.content_urls.desktop && data.content_urls.desktop.page)?data.content_urls.desktop.page:'https://en.wikipedia.org/wiki/'+encodeURIComponent(wikiSlug);
          if(data.thumbnail){artistThumb.src=data.thumbnail.source;artistThumb.style.display='inline-block'; artistThumb.alt=data.title+' portrait';}
        }catch(e){
          modalTitle.textContent=wikiSlug.replace(/_/g,' ');
          modalDesc.textContent='Could not fetch Wikipedia info.';
        }
      });
    });
    
    document.querySelectorAll('.modal-close').forEach(btn=>{
      btn.addEventListener('click',()=>{
        previewModal.classList.remove('show');
        previewModal.setAttribute('aria-hidden','true');
      });
    });
    previewModal.addEventListener('click',e=>{
      if(e.target===previewModal){previewModal.classList.remove('show');previewModal.setAttribute('aria-hidden','true');}
    });
    document.addEventListener('keydown',e=>{
      if(e.key==='Escape'){previewModal.classList.remove('show');previewModal.setAttribute('aria-hidden','true');}
    });
    });
    